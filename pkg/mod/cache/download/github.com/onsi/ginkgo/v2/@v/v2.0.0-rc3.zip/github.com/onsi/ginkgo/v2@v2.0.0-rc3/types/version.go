package types

const VERSION = "2.0.0-rc3"
